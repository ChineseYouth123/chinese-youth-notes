import fs from "fs";
import path from "path";

export default {
  paths() {
    const dir = "public/pages/library/red-books";
    if (!fs.existsSync(dir)) return [];
    const pages = [];
    const entries = fs.readdirSync(dir);
    for (const entry of entries) {
      if (entry.endsWith(".pdf")) {
        pages.push({ params: { name: path.parse(entry).name } });
      }
    }
    console.info("红色书籍PDF动态路由：", pages);
    return pages;
  },
};
