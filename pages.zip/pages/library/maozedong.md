---
title: 毛泽东
---

# 毛泽东

毛泽东相关电子图书资料。

<script setup>
import { data as pdfData } from '../../.vitepress/theme/utils/libraryFiles.data.mjs'

const mdGlob = import.meta.glob('/pages/library/maozedong/*.md')

const files = [
  ...Object.keys(mdGlob).map((path) => {
    const name = path.split('/').pop().replace(/\.md$/, '')
    return { path, name, link: '/pages/library/maozedong/' + encodeURIComponent(name), ext: '.md' }
  }),
  ...pdfData['maozedong'],
].sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'))
</script>

<FileList :files="files" />
