import fs from "fs";
import path from "path";

export default {
  paths() {
    const dir = "public/pages/library/materials";
    if (!fs.existsSync(dir)) return [];
    const pages = [];
    const entries = fs.readdirSync(dir);
    for (const entry of entries) {
      if (entry.endsWith(".pdf")) {
        pages.push({ params: { name: path.parse(entry).name } });
      }
    }
    console.info("PDF文件动态路由：", pages);
    return pages;
  },
};
